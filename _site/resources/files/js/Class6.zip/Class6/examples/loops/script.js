function processForm() {
    
}

function determineAverage() {
}